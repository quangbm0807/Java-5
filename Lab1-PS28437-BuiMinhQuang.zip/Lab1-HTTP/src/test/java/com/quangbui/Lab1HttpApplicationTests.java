package com.quangbui;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab1HttpApplicationTests {

	@Test
	void contextLoads() {
	}

}
