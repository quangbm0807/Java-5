package com.quangbui;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab2Ps28437ApplicationTests {

	@Test
	void contextLoads() {
	}

}
